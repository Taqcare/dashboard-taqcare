# bolt-admin-dashboard

[Edit in StackBlitz next generation editor ⚡️](https://stackblitz.com/~/github.com/donvito/bolt-admin-dashboard)